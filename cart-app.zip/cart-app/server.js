const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const CartItem = require('./models/CartItem');

const app = express();
app.use(bodyParser.json());

// Connect to MongoDB
mongoose.connect('mongodb://127.0.0.1:27017/cartDB', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => console.log("MongoDB Connected"))
  .catch(err => console.log(err));

/**
 * 1. Add product to cart
 * If product exists, increase its quantity
 */
app.post('/cart', async (req, res) => {
  try {
    const { name, category, price } = req.body;
    let item = await CartItem.findOne({ name });

    if (item) {
      item.quantity += 1;
      await item.save();
      return res.json({ message: "Quantity increased", item });
    }

    item = new CartItem({ name, category, price, quantity: 1 });
    await item.save();
    res.json({ message: "Product added to cart", item });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

/**
 * 2. Remove product from cart
 */
app.delete('/cart/:name', async (req, res) => {
  try {
    const item = await CartItem.findOneAndDelete({ name: req.params.name });
    if (!item) return res.status(404).json({ message: "Product not found" });
    res.json({ message: "Product removed", item });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

/**
 * 3. Retrieve product by name
 */
app.get('/cart/:name', async (req, res) => {
  try {
    const item = await CartItem.findOne({ name: req.params.name });
    if (!item) return res.status(404).json({ message: "Product not found" });
    res.json(item);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

/**
 * 4. Update product quantity
 */
app.put('/cart/:name', async (req, res) => {
  try {
    const { quantity } = req.body;
    const item = await CartItem.findOne({ name: req.params.name });

    if (!item) return res.status(404).json({ message: "Product not found" });

    item.quantity = quantity;
    await item.save();
    res.json({ message: "Quantity updated", item });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

/**
 * Extra: Get all cart items
 */
app.get('/cart', async (req, res) => {
  try {
    const items = await CartItem.find();
    res.json(items);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.listen(5000, () => console.log("Server running on port 5000"));
